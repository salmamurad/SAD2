package org.springframework.samples.petclinic.util;

/**
 * A simple utility class for demonstration purposes.
 * Contains a function to be unit tested 50 times.
 */
public class FunUtility {

    /**
     * A simple function that calculates the square of a number.
     * @param number The input number.
     * @return The square of the number.
     */
    public static int square(int number) {
        return number * number;
    }
}
